<html>
	<head>
		<title>Motorsport (Konto erstellt)</title>
		<meta charset="UTF8"/>
		<link rel="stylesheet" type="text/css" href="css\style.css"/>
		<link rel="stylesheet" type="text/css" href="css\form.css"/>
<?php
?>
	</head>
	<body>
<?php 
		require("php/header.php"); 
?>
		<main>
			<div class="zentralerInfotext">
				<p>Vielen Dank für Deine Registrierung auf dieser Seite.</p>
				<p>Es wurde eine Nachricht an Deine Emailadresse geschickt. Um die Registrierung abzuschließen, klicke bitte auf den dort enthaltenen Link. Danach kannst Du Dich mit Deinen Benutzerdaten im Veranstalterbereich anmelden.</p>
			</div>
		</main>
<?php	
		require("php/footer.php"); 
?>
	</body>
</html>