<header id="header">
	<nav id="homeNav">
		<ul>
			<li><a class="activeLink1" href="veranstalterliste.php">Home</a></li>
			<li><a class="activeLink1" href="veranstalterliste.php">Impressum</a></li>
			<li><a class="activeLink1" href="veranstalterliste.php">Kontakt</a></li>
		</ul>
	</nav>
	<nav id="accountNav">
		<ul>
			<li><a class="activeLink1" href="veranstalter.php">Veranstalterbereich</a></li>
		</ul>
	</nav>
</header>
