		<footer>
			<nav id="footNav">
				<ul>
					<li>
						<a class="activeLink1" href="#header">Zum Seitenanfang</a>
					</li>
				</ul>
			</nav>
			<div>
				<legend id="footLegend">Letzte Aktualisierung: Revision 70 vom 22.10.2020 17:30</legend>
			</div>
		</footer>
