<?php
if($_SERVER['SERVER_NAME'] == 'localhost')
{
	$DBHOST='localhost';
	$DBNAME='motorsport';
	$DBUSER='root';
	$DBPASS='';
}
else
{
	$DBHOST='10.35.46.173:3306';
	$DBNAME='k143704_mtrsprt';
	$DBUSER='k143704_root';
	$DBPASS='&22uuS4p';
}
?>